#include <iostream>
#include <fstream>
using namespace std;
bool SoBTh(unsigned int a){
    if (a/10 == 0){
        return false;
    }
    int tempt=0;
    if ((a%10 == 0) && ((a/10) > 0)){
        a /= 10;
        if (a<10){
            return true;
        }
    }
    while (a != 0){
        if (a%10 <= tempt){
            return false;
        }
        tempt = a%10;
        a /= 10;
    }
    return true;
}
int main(){
    freopen("SOBTH.INP","r",stdin);
    freopen("SOBTH.OUT","w",stdout);
    unsigned int a,b;
    cin>>a>>b;
    bool check = false;
    for (unsigned int i=a; i<=b; i++){
        if (SoBTh(i)){
            cout<<i<<" ";
            check = true;
        }
    }
    if (!check){
        cout<<0;
    }
}
