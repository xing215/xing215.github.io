#include <iostream>
#include <fstream>
using namespace std;
bool isPrime(unsigned long n){
    if (n<2){
        return false;
    }
    for (int i=2; (i*i)<=n; i++){
        if (n % i == 0){
            return false;
        }
    }
    return true;
}
unsigned int charSum(unsigned long n){
    unsigned int Sum = 0;
    while (n != 0){
        Sum += (n%10);
        n /= 10;
    }
    return Sum;
}
bool isHPrime(unsigned long a, unsigned short h){
    if (!isPrime(a)){
        return false;
    }
    if (charSum(a) != h){
        return false;
    }
    return true;
}
void hprimePrint(unsigned long n, unsigned short h){
    bool first=true;
    for (unsigned long i=2; i<=n; i++){
        if (isHPrime(i,h)){
            if (!first){
                cout<<" ";
            }
            cout<<i;
            first = false;
        }
    }
    if (first){
        cout<<-1;
    }
}
int main(){
    freopen("hprime.inp","r",stdin);
    freopen("hprime.out","w",stdout);
    unsigned long n;
    unsigned short h;
    cin>>n>>h;
    hprimePrint(n,h);
}

