#include <iostream>
#include <fstream>
using namespace std;
int n, a[1000000], b[1000000];
int main(){
    freopen("PTCHUNG.INP","r",stdin);
    freopen("PTCHUNG.OUT","w",stdout);
    cin>>n;
    for (unsigned int i = 0; i<n; i++){
        cin>>a[i];
    }
    for (unsigned int i = 0; i<n; i++){
        cin>>b[i];
    }
    bool checker = false;
    for (unsigned int i = 0; i<n; i++){
        for (unsigned int j = 0; j<n; j++){
            if (a[i] == b[j]){
                checker = true;
                cout<<a[i]<<" ";
                break;
            }
        }
    }
    if (!checker){
        cout<<"NO";
    }
}
